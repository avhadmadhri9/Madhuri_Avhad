package com.rjprogram.emp;

import java.sql.Connection;
import java.sql.DriverManager;

 class DBConnection {
   static Connection con;
    public static Connection createDBConnetion(){

        try{
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3306/employeedb?useSSL=false";
            String username="root";
            String password="SHA256";
            con=DriverManager.getConnection(url,username,password);
        }
        catch (Exception ex){
            ex.printStackTrace();
        }

        //get connection
        return con;
    }
}
